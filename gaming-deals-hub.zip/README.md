Local dev server

To start the local static server (requires Node.js):

```powershell
# from the site folder
& 'C:\Program Files\nodejs\node.exe' 'serve.js' '.'
# or via npm
npm install
npm start
```

Then open http://localhost:8080/ in your browser.
