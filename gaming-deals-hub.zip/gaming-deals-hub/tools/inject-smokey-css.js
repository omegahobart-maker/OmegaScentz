// inject-smokey-css.js
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const files = fs.readdirSync(root).filter(f => f.endsWith('.html'));
const linkTag = '  <link rel="stylesheet" href="smokey-bg.css">\n';

files.forEach(file => {
  const p = path.join(root, file);
  let content = fs.readFileSync(p, 'utf8');
  if (content.indexOf('smokey-bg.css') !== -1) {
    console.log('Skipped (already present):', file);
    return;
  }
  if (content.indexOf('</head>') !== -1) {
    content = content.replace('</head>', linkTag + '</head>');
    fs.writeFileSync(p, content, 'utf8');
    console.log('Injected into:', file);
  } else {
    console.log('No </head> in', file);
  }
});
