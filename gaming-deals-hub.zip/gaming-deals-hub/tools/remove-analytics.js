// remove-analytics.js
// Removes Google gtag snippet and <script src="analytics.js"> from all HTML files
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const files = fs.readdirSync(root).filter(f => f.endsWith('.html'));

const gtagRegex = /<!-- Google tag \(gtag\.js\) -->[\s\S]*?gtag\('config',[\s\S]*?\);\n<\/script>\n?/gi;
const analyticsScriptRegex = /\s*<script\s+src=\"analytics\.js\"\s+defer><\/script>\s*\n?/gi;

files.forEach(file => {
  const p = path.join(root, file);
  let content = fs.readFileSync(p, 'utf8');
  const orig = content;
  content = content.replace(gtagRegex, '');
  content = content.replace(analyticsScriptRegex, '');
  if (content !== orig) {
    fs.writeFileSync(p, content, 'utf8');
    console.log('Cleaned:', file);
  } else {
    console.log('No analytics found in:', file);
  }
});

// remove analytics.js if exists
const analyticsPath = path.join(root, 'analytics.js');
if (fs.existsSync(analyticsPath)){
  fs.unlinkSync(analyticsPath);
  console.log('Deleted analytics.js');
} else {
  console.log('analytics.js not found');
}
