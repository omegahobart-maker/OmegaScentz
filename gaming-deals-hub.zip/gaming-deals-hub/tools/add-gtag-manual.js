// add-gtag-manual.js
// Inserts the provided Google gtag snippet immediately after the opening <head> tag for all .html files
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const files = fs.readdirSync(root).filter(f => f.endsWith('.html'));

const snippet = `<!-- Google tag (gtag.js) -->\n<script async src="https://www.googletagmanager.com/gtag/js?id=G-7XGDSXQSVC"></script>\n<script>\n  window.dataLayer = window.dataLayer || [];\n  function gtag(){dataLayer.push(arguments);}\n  gtag('js', new Date());\n\n  gtag('config', 'G-7XGDSXQSVC');\n</script>\n`;

files.forEach(file => {
  const p = path.join(root, file);
  let content = fs.readFileSync(p, 'utf8');
  if (content.indexOf('gtag/js?id=G-7XGDSXQSVC') !== -1) {
    console.log('Skipped (already has gtag):', file);
    return;
  }

  const headRegex = /<head(\s[^>]*)?>/i;
  const m = content.match(headRegex);
  if (m) {
    const idx = m.index + m[0].length;
    content = content.slice(0, idx) + '\n' + snippet + content.slice(idx);
    fs.writeFileSync(p, content, 'utf8');
    console.log('Injected gtag into:', file);
  } else {
    console.log('No <head> tag found in', file);
  }
});
