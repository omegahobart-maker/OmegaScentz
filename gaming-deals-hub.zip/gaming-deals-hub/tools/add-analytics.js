// add-analytics.js
// Inserts a <script src="analytics.js" defer></script> before </head> for all .html files
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const files = fs.readdirSync(root).filter(f => f.endsWith('.html'));

files.forEach(file => {
  const p = path.join(root, file);
  let content = fs.readFileSync(p, 'utf8');
  if (content.indexOf('analytics.js') !== -1) return;
  const insert = "  <script src=\"analytics.js\" defer></script>\n";
  if (content.indexOf('</head>') !== -1){
    content = content.replace('</head>', insert + '</head>');
    fs.writeFileSync(p, content, 'utf8');
    console.log('Updated:', file);
  } else {
    console.log('No </head> found in', file);
  }
});
