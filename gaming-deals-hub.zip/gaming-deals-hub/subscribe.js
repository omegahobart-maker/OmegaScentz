document.addEventListener('DOMContentLoaded', function () {
  const form = document.getElementById('subscribe-form');
  if (!form) return;

  form.addEventListener('submit', async function (e) {
    e.preventDefault();
    const input = form.querySelector('input[name="email"]');
    const email = input && input.value && input.value.trim();
    if (!email) return alert('Please enter a valid email');

    try {
      const res = await fetch('/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      if (res.ok) {
        input.value = '';
        alert('Thanks — you have been subscribed!');
      } else {
        const data = await res.json().catch(()=>({}));
        alert(data.error || 'Subscription failed. Please try again.');
      }
    } catch (err) {
      alert('Network error. Please try again later.');
    }
  });
});